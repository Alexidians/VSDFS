import os
import json
import subprocess
import shutil
import sys
try:
    import ramdisk
except Exception as e:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "ramdisk"])
    import ramdisk
print("Make sure to have all requirements met on this device:", os.path.abspath("requirements"))
print("Only Tested On Windows 10!!!")

class VSDFSFile:
    def __init__(self, vsdfs_path):
        """
        Initialize the VSDFS class by providing the path to an existing .vsdfs file (internally using .vhdx).
        """
        self.vsdfs_path = vsdfs_path  # Use .vsdfs directly
        self.vhdx_path = vsdfs_path + "/.vhdx"  # Internally, it uses .vhdx format for disk
        self.metadata_path = vsdfs_path + "/.metadata.json"

        if not os.path.exists(self.vhdx_path):
            raise FileNotFoundError(f"The virtual disk file does not exist: {self.vhdx_path}")
        
        # Load metadata for the virtual disk
        self.disk_info = self._load_metadata()

    def _load_metadata(self):
        """
        Load metadata information about the virtual disk (such as type, size, removable, readonly).
        """
        if not os.path.exists(self.metadata_path):
            raise ValueError(f"No metadata found for {self.vsdfs_path}")
        
        try:
            with open(self.metadata_path, "r") as metadata_file:
                return json.load(metadata_file)  # Read metadata as JSON
        except Exception as e:
            raise ValueError(f"Error loading metadata: {e}")

    def _write_metadata(self, metadata):
        """
        Load metadata information about the virtual disk (such as type, size, removable, readonly).
        """
        if not os.path.exists(self.metadata_path):
            raise ValueError(f"No metadata found for {self.vsdfs_path}")
        
        try:
            with open(self.metadata_path, "w") as metadata_file:
                metadata_file.write(json.dumps(metadata))  # Read metadata as JSON
        except Exception as e:
            raise ValueError(f"Error loading metadata: {e}")

    def get_disk_info(self):
        """
        Get information about the virtual disk (size, type, removable, readonly).
        """
        return self.disk_info

    def mount(self, remove=False):
        """
        Mount the .vsdfs file (internally .vhdx) as a virtual drive using ImDisk.
        - Uses ImDisk to mount or unmount the virtual disk.
        """
        if not shutil.which("imdisk"):
            raise EnvironmentError("imdisk is not installed or not in PATH")
       
        if self.disk_info.get("mountpoint", None) == None:
            if remove == False:
                self.drive_letter = self.get_available_mount_point()
        else:
            if remove == False:
                self.drive_letter = self.disk_info["mountpoint"]

        if remove:
            # Unmount the disk
            unmount_command = ["imdisk", "-d", "-m", f"{self.drive_letter}"]
            try:
                subprocess.run(unmount_command, check=True)
                print(f"Unmounted the virtual drive from {self.drive_letter}")
            except subprocess.CalledProcessError as e:
                print(f"Error unmounting drive {self.drive_letter} {e}")
        else:
            # Mount the disk
            mount_command = [
                "imdisk", 
                "-a",
                "-f", self.vhdx_path, 
                "-m", f"{self.drive_letter}"
            ]
            if self.disk_info.get("drive_type", None) != None:
                mount_command.append("-o")
                mount_command.append(self.disk_info["drive_type"])
            if self.disk_info.get("removable", True):
                mount_command.append("-o")
                mount_command.append("rem")
            else:
                mount_command.append("-o")
                mount_command.append("fix")
            if self.disk_info.get("readonly", False):
                mount_command.append("-o")
                mount_command.append("ro")
            else:
                mount_command.append("-o")
                mount_command.append("rw")
            try:
                subprocess.run(mount_command, check=True)
                print(f"Mounted {self.vsdfs_path} to drive {self.drive_letter}")
            except subprocess.CalledProcessError as e:
                print(f"Error mounting the VHDX file: {e}")
        
        return self.drive_letter

    def get_available_mount_point(self):
        """
        Finds the first available drive letter on a Windows machine.
        It checks all letters from A to Z and returns the first available one.
        
        Returns:
            str: The first available drive letter (e.g., 'C:', 'D:', etc.)
        
        Raises:
            Exception: If no available drive letters are found.
        """
        used_letters = set()

        # Check each letter from A to Z
        for letter in range(65, 91):  # ASCII values for 'A' to 'Z'
            drive_letter = chr(letter) + ":\\"
            if os.path.exists(drive_letter):
                used_letters.add(drive_letter[0])  # Add the letter (e.g., 'C')

        # Find the first available drive letter
        for letter in range(65, 91):  # ASCII values for 'A' to 'Z'
            drive_letter = chr(letter) + ":\\"
            if drive_letter[0] not in used_letters:
                return drive_letter[:-1]  # Return without backslash (e.g., 'C:')
        
        raise Exception("No available drive letters found.")

    def resize(self, size):
        cmd = ["qemu-img", "resize", self.vhdx_path, size]
        subprocess.run(cmd)

    
    def set_removable(self, removable):
        self.disk_info["removable"] = removable
        self._write_metadata(self.disk_info)

    def set_readonly(self, readonly):
        self.disk_info["readonly"] = readonly
        self._write_metadata(self.disk_info)

    def set_drive_type(self, drive_type):
        valid_drive_type = ["hd", "cd", "fd", "raw"]
        if drive_type not in valid_drive_type:
            raise ValueError(str(drive_type), "Is not a valid drive type from: " + json.dumps(valid_drive_type))
        self.disk_info["drive_type"] = drive_type
        self._write_metadata(self.disk_info)

    def set_mountpoint(self, mountpoint):
        self.disk_info["mountpoint"] = mountpoint
        self._write_metadata(self.disk_info)


class VSDFS:
    def __init__(self, vsdfs_path):
        self.VSDFSFile = VSDFSFile
    def create_empty_vsdfs(path, size):
        """
        Create an empty .vsdfs file (internally a .vhdx file) with the specified size using QEMU.
        """
        os.makedirs(path, exist_ok=True)
        vhdx_path = path + "/.vhdx"  # Internally uses .vhdx file
        metadata_path = path + "/.metadata.json"  # Metadata file

        # Create the VHDX file with the specified size (using QEMU)
        subprocess.run(["qemu-img", "create", "-f", "vhdx", vhdx_path, str(size)], check=True)
        subprocess.run(["qemu-img", "resize", vhdx_path, size])

        # Create the metadata file (store information about the virtual disk)
        disk_info = {
            "size": size,
            "drive_type": "hd",
            "removable": False,
            "readonly": False,
            "mountpoint": None
        }

        with open(metadata_path, "w") as metadata_file:
            metadata_file.write(json.dumps(disk_info))  # Save metadata as JSON

        print(f"Empty .vsdfs file created at: {path}")
        print(f"Disk properties saved in: {metadata_path}")